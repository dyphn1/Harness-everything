export class Element {
  constructor(value) {
    this._value = value;
    this._next = null;
  }

  get value() {
    return this._value;
  }

  get next() {
    return this._next;
  }

  set next(element) {
    this._next = element;
  }
}

export class List {
  constructor(values = []) {
    this._head = null;
    this._length = 0;
    for (const value of values) {
      this.add(value);
    }
  }

  add(nextValue) {
    const element = nextValue instanceof Element ? nextValue : new Element(nextValue);
    element.next = this._head;
    this._head = element;
    this._length += 1;
  }

  get length() {
    return this._length;
  }

  get head() {
    return this._head;
  }

  toArray() {
    const values = [];
    for (let element = this._head; element !== null; element = element.next) {
      values.push(element.value);
    }
    return values;
  }

  reverse() {
    let previous = null;
    let current = this._head;
    while (current !== null) {
      const next = current.next;
      current.next = previous;
      previous = current;
      current = next;
    }
    this._head = previous;
    return this;
  }
}
