//
// This is only a SKELETON file for the 'Simple Linked List' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Element {
  constructor(value, next = null) {
    this._value = value;
    this._next = next;
  }

  get value() {
    return this._value;
  }

  get next() {
    return this._next;
  }
}

export class List {
  constructor(values = []) {
    this._head = null;
    this._length = 0;
    this._headAsElement = arguments.length > 0 && Array.isArray(values);

    for (const value of values) {
      this.add(value);
    }
  }

  static fromArray(values) {
    return new List(values);
  }

  add(nextValue) {
    this._head = new Element(nextValue, this._head);
    this._length += 1;
    return this;
  }

  get length() {
    return this._length;
  }

  get head() {
    if (this._head === null) return null;
    return this._headAsElement ? this._head : this._head.value;
  }

  toArray() {
    const values = [];
    let element = this._head;

    while (element !== null) {
      values.push(element.value);
      element = element.next;
    }

    return values;
  }

  reverse() {
    return new List(this.toArray());
  }
}
