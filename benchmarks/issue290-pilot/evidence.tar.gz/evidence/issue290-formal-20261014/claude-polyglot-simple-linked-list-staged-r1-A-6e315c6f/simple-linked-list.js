//
// Simple Linked List: a singly linked list of song IDs that can be reversed.
//

export class Element {
  #value;
  #next;

  constructor(value, next = null) {
    this.#value = value;
    this.#next = next;
  }

  get value() {
    return this.#value;
  }

  get next() {
    return this.#next;
  }

  set next(element) {
    this.#next = element;
  }
}

export class List {
  #head = null;
  #length = 0;

  constructor(values = []) {
    for (const value of values) {
      this.add(value);
    }
  }

  // Accepts a raw value or an Element; either way the new element becomes the head.
  add(nextValue) {
    const element = nextValue instanceof Element ? nextValue : new Element(nextValue);
    element.next = this.#head;
    this.#head = element;
    this.#length += 1;
  }

  get length() {
    return this.#length;
  }

  get head() {
    return this.#head;
  }

  // Values in head-to-tail order.
  toArray() {
    const values = [];
    for (let current = this.#head; current; current = current.next) {
      values.push(current.value);
    }
    return values;
  }

  // Relinks the existing elements in place, so the list is reversed rather than copied.
  reverse() {
    let previous = null;
    let current = this.#head;
    while (current) {
      const next = current.next;
      current.next = previous;
      previous = current;
      current = next;
    }
    this.#head = previous;
    return this;
  }
}
