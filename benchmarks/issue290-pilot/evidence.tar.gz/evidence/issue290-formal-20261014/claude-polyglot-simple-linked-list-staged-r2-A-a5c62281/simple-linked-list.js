//
// This is only a SKELETON file for the 'Simple Linked List' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Element {
  #value;
  #next;

  constructor(value, next = null) {
    this.#value = value;
    this.#next = next;
  }

  get value() {
    return this.#value;
  }

  get next() {
    return this.#next;
  }

  set next(element) {
    this.#next = element;
  }
}

export class List {
  #head = null;
  #length = 0;

  constructor(values = []) {
    for (const value of values) {
      this.add(value);
    }
  }

  add(nextValue) {
    const element = nextValue instanceof Element ? nextValue : new Element(nextValue);
    element.next = this.#head;
    this.#head = element;
    this.#length += 1;
    return this;
  }

  get length() {
    return this.#length;
  }

  get head() {
    return this.#head;
  }

  toArray() {
    const values = [];
    for (let element = this.#head; element !== null; element = element.next) {
      values.push(element.value);
    }
    return values;
  }

  reverse() {
    let previous = null;
    let current = this.#head;
    while (current !== null) {
      const next = current.next;
      current.next = previous;
      previous = current;
      current = next;
    }
    this.#head = previous;
    return this;
  }
}
