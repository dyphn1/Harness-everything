export class Element {
  #value;
  #next;

  constructor(value, next = null) {
    this.#value = value;
    this.#next = next;
  }

  get value() {
    return this.#value;
  }

  get next() {
    return this.#next;
  }
}

export class List {
  #head = null;
  #length = 0;

  constructor(values = []) {
    for (const value of values) {
      this.add(new Element(value));
    }
  }

  add(element) {
    this.#head = new Element(element.value, this.#head);
    this.#length += 1;
  }

  get length() {
    return this.#length;
  }

  get head() {
    return this.#head;
  }

  toArray() {
    const values = [];
    for (let node = this.#head; node !== null; node = node.next) {
      values.push(node.value);
    }
    return values;
  }

  reverse() {
    let reversed = null;
    for (let node = this.#head; node !== null; node = node.next) {
      reversed = new Element(node.value, reversed);
    }
    this.#head = reversed;
    return this;
  }
}
